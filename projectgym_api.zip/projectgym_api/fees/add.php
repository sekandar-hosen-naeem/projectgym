<?php 
include '../connection.php';
include '../auth_check.php';

if($_POST){
	 
	if($_POST['member_id']){
		$sql = "insert into `fees` set 
		member_id='{$_POST['member_id']}',
		fees_month='{$_POST['fees_month']}',
		fees_year='{$_POST['fees_year']}',
		pay_date='{$_POST['pay_date']}',
		pay_status='{$_POST['pay_status']}',
		amount='{$_POST['amount']}'";
		
		$result=$db->query($sql);
		if($result)
			echo json_encode(array("message" => "Successful saved.",'error'=>0));
		else
			echo json_encode(array("message" => "Failed.",'error'=>1));
	}else{
		echo json_encode(array("message" => "Name, email and password are required.",'error'=>1));
	}
}

