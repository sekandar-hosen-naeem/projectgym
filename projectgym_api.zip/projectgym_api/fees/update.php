<?php
include '../connection.php';
include '../auth_check.php';


if($_POST){
	$sql = "update `fees` set 
		member_id='{$_POST['member_id']}',
		fees_month='{$_POST['fees_month']}',
		fees_year='{$_POST['fees_year']}',
		pay_date='{$_POST['pay_date']}',
		pay_status='{$_POST['pay_status']}',
		amount='{$_POST['amount']}'
		where id='{$_POST['id']}'";
	
	$result=$db->query($sql);
	if($result)
		echo json_encode(array("message" => "Successful updated."));
	else
		echo json_encode(array("message" => "Failed."));
	
}

