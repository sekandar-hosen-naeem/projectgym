<?php
include '../connection.php';
include '../auth_check.php';


if($_POST){
	$sql = "update `member` set 
		name='{$_POST['name']}',
		contact_no='{$_POST['contact_no']}',
		fees='{$_POST['fees']}',
		joining_date='{$_POST['joining_date']}'
		where id='{$_POST['id']}'";
	
	$result=$db->query($sql);
	if($result)
		echo json_encode(array("message" => "Successful updated."));
	else
		echo json_encode(array("message" => "Failed."));
	
}

